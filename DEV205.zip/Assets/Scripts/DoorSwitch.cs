using UnityEngine;

public class DoorSwitch : MonoBehaviour
{
    public GameObject door;

    private void OnTriggerEnter(Collider other)
    {
        door.SetActive(false);
    }
}
