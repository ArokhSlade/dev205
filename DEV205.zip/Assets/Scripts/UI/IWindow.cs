public interface IWindow
{
    void Show();
    void Hide();
}