using UnityEngine;

public class LevelEndTrigger : MonoBehaviour
{
    [SerializeField]
    private SceneLoader sceneLoader;

    [SerializeField]
    private int sceneIndexToLoad;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.gameObject.CompareTag("Player"))
        {
            return;
        }
        // [TODO] show win window
        sceneLoader.LoadSceneByIndex(sceneIndexToLoad);
    }
}
